def find_anagrams(word, word_list):
    anagrams = []
    sorted_word = sorted(word)

    for w in word_list:
        if sorted(w) == sorted_word and w != word:
            anagrams.append(w)

    return anagrams


# Load dict file
with open("words.txt") as f:
    words = [line.strip().lower() for line in f]

user_word = input("Enter a word: ").lower()

results = find_anagrams(user_word, words)

print("Anagrams found:")
for r in results:
    print(r)